/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercice1;

/**
 *
 * @author sebas
 */
public class Triangle extends Polygone 
{
    int perim;
    int surf;
    
    public Triangle()
    {
        perim=tab[0].Calcul()+tab[1].Calcul()+tab[2].Calcul();
        surf=(perim*((perim-tab[0].Calcul())*(perim-tab[1].Calcul())*(perim-tab[2].Calcul())));
    }
    
    public void affiche_tring()
    {
        System.out.print("\nperimetre: " +perim+ "\n surface: " +surf);
    }
}
