/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercice1;

/**
 *
 * @author sebas
 */
public class Rectangle extends Polygone
{
    int perim;
    int surf;
    
    public Rectangle()
    {
        perim=perim=tab[0].Calcul()+tab[1].Calcul()+tab[2].Calcul()+tab[3].Calcul();
        surf=tab[0].Calcul()*tab[1].Calcul();
    }
    
    public void affiche_rec()
    {
        System.out.print("\nperimetre: " +perim+ "\n surface: " +surf);
    }
}
