/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package exercice1;

import java.util.Scanner;
/**
 *
 * @author sebas
 */
public class Test 
{
    public static void main(String[] args)
    {
        Scanner sc=new Scanner (System.in);
     /*   Point p1= new Point();
        int x1=0;
        int y1;
        System.out.print("Saisissez l'abscisse de votre deuxieme point.\n");
        x1 = sc.nextInt(); 
        System.out.print("\nSaisissez l'ordonee de votre deuxieme point.\n");
        y1 = sc.nextInt();
        Point p2= new Point(x1, y1);
        System.out.print("\nSaisissez le nom de votre troisieme point.\n");
        String nom3;
        nom3= sc.nextLine();
        nom3= sc.nextLine();
        Point p3= new Point (nom3);
        p2.setnom(nom3);
        p1.Affiche();
        p2.Affiche();
        p3.Affiche();
        
        Segment s1=new Segment (p1, p2);
        s1.Affiche();
        Segment s2=new Segment (p2, p3);
        s2.Affiche();
        s1.Deplacer(p3.getx(), p3.gety(), p3.gety(), p3.gety());
        s1.Affiche();

        */
     
      /*  Point p1= new Point (3, 5);
        Point p2= new Point (5,6);
        Point p3= new Point (2, 3);
        
        Segment seg1 = new Segment(p1, p2);
        Segment seg2 = new Segment (p1, p3);
        Segment [] tab = new Segment[2];
        tab[0]=seg1;
        tab[1]=seg2;
        Polygone poly = new Polygone (2,tab);
        poly.Afficher();

        */
     
     Point p1= new Point (3, 5);
        Point p2= new Point (5,6);
        Point p3= new Point (2, 3);
        
        Segment seg1 = new Segment(p1, p2);
        Segment seg2 = new Segment (p1, p3);
        Segment seg3 =new Segment (p2, p3);
        
        Segment [] tab = new Segment[3];
        tab[0]=seg1;
        tab[1]=seg2;
        tab[2]=seg3;
        Polygone poly = new Polygone (3,tab);
        Triangle tring= new Triangle();
        tring.affiche_tring();
        
     
    }
    
    
    
}
