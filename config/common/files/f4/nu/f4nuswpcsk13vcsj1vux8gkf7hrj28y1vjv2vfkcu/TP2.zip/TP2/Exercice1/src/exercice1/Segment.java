/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercice1;


/**
 *
 * @author sebas
 */
public class Segment 
{
    protected Point p1;
    protected Point p2;
    protected int taille;
    
    public Segment()
    {
        p1=new Point();
        p2=new Point();
        taille=0;
    }
    
    public Segment(Point point1, Point point2)
    {
        p1=point1;
        p2=point2;
        taille=0;
    }
    
    protected int Calcul()
    {
        return ((p1.getx()-p2.getx())^2+(p1.gety()-p2.gety())^2)^1/2;
    }
    
    public void Deplacer(int nouvx1, int nouvy1, int nouvx2, int nouvy2)
    {
        p1.Deplace(nouvx1, nouvy1);
        p2.Deplace(nouvx2, nouvy2);
    }
    
    public void Affiche()
    {
        System.out.print("\nLe segment est composé du point");
        p1.Affiche();
        System.out.print("\net du point");
        p2.Affiche();
        System.out.print("\nIl a une longueur de " +Calcul());
        
    }
            
}
