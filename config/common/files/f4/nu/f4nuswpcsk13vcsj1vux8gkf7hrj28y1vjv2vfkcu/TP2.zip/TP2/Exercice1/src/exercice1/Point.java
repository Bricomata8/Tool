/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercice1;

/**
 *
 * @author sebas
 */
public class Point 
{
    private String nom;
    private int x;
    private int y;
    
    public Point()
    {
        x=0;
        y=0;
        nom="";
    }
    
    public Point(int abscisse, int ordonnee)
    {
        x=abscisse;
        y=ordonnee;
        nom="";
    }
    
    public Point(String name)
    {
        x=0;
        y=0;
        nom=name;
    }
    
    public void setnom(String nouvnom)
    {
        nom=nouvnom;
    }
    
    public void Affiche()
    {
        System.out.print("\nNom=" +nom+ "\nAbscisse=" +x+ "\nOrdonnee=" +y);
    }
    
    public int getx()
    {
        return x;
    }
    
    public int gety()
    {
        return y;
    }
    
    private void setx(int nouvx)
    {
        x=nouvx;
    }
    
    private void sety (int nouvy)
    {
        y=nouvy;
    }
    
    public void Deplace(int nouvx, int nouvy)
    {
        setx(nouvx);
        sety(nouvy);
    }
}
