/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercice1;

/**
 *
 * @author sebas
 */
public class Polygone 
{
    Segment [] tab;
    int nbr;
    
    public Polygone()
    {
        tab=null;
        nbr=0;
    }
    
    public Polygone(int card)
    {
        nbr=card;
        tab= new Segment[nbr];
    }
    
    public Polygone(int card, Segment[] seg)
    {
        nbr=card;
        tab=seg;
    }
    
    public void Afficher()
    {
        for(int i=0; i<nbr; i++)
        {
            tab[i].Affiche();
        }

    }
            
}
