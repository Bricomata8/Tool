package com.example.android;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.Toast;

public class MainActivity extends Activity {

	public void onCreate(Bundle savedInstanceState) {
		Toast.makeText(getApplicationContext(), "Sélectionnez les 4 points SVP", Toast.LENGTH_LONG).show();
		super.onCreate(savedInstanceState);
        Dessin dessin = new Dessin(this);
        dessin.setBackgroundColor(Color.WHITE);
        setContentView(dessin);
	}	
}
