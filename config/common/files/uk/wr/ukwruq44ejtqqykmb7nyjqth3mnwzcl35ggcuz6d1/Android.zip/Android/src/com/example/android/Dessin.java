package com.example.android;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.widget.Toast;

public class Dessin extends View implements OnTouchListener {

    List<Point> points = new ArrayList<Point>();//déclaration d'une liste des Points
    Paint paint = new Paint();

    public Dessin(Context context) {//Constructeur
        super(context);
        this.setOnTouchListener(this);
        
        paint.setStrokeWidth(4); 
        
    }
    @Override
    public void onDraw(Canvas canvas) {
    	char A='A'; //on initialise le premier point
        for (Point point : points) {
        	paint.setColor(Color.BLACK);
        	canvas.drawPoint(point.x, point.y, paint); //on affiche le point de l'utilisateur
			canvas.drawText(A+"", point.x-15, point.y-15, paint);// on affiche le nom du point
			A++;//on passe au point suivant 
        }
    	if (points.size()==4){
			paint.setColor(Color.RED);
			if (distance(points.get(0),points.get(2))+distance(points.get(2),points.get(1)) < distance(points.get(0),points.get(3))+distance(points.get(3),points.get(1)))      	
			{//On compare les distances et on trace le chemin le plus court 
				canvas.drawLine(points.get(0).x,points.get(0).y,points.get(2).x ,points.get(2).y,paint);
				canvas.drawLine(points.get(2).x,points.get(2).y,points.get(1).x ,points.get(1).y,paint);
			}
			else{
				canvas.drawLine(points.get(0).x,points.get(0).y,points.get(3).x ,points.get(3).y,paint);
				canvas.drawLine(points.get(3).x,points.get(3).y,points.get(1).x ,points.get(1).y,paint);
			}
			Toast.makeText(getContext(), "Le court chemin entre A et B", Toast.LENGTH_SHORT).show();//on affiche un commentaire
			points.clear();
    	}
    }
    

    public boolean onTouch(View view, MotionEvent event) {
    	
         if(event.getAction() != MotionEvent.ACTION_DOWN) //on détecte que premier mouvement du toucher  
        	 return super.onTouchEvent(event);
         		points.add(new Point((int)event.getX(),(int)event.getY()));//on met les coordonnées des points sélectionnés dans la liste
         		view.invalidate();//on affiche les points
      
         return true;
    }
    
    public double distance(Point a,Point b){// on calcule la distance euclidienne
    	return Math.sqrt(Math.pow(a.x-b.x,2)+Math.pow(a.y-b.y,2));
    }
} 
