/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author karll
 */
public class Point {
    
    private int x;
    private int y;
    private String Nom;
    

 
 public Point()
{
   x= 0;
   y= 0;
   Nom= null;
}  
 public Point(int x1, int y1){
    
    x = x1;
    y = y1;
    
}
 
 public Point(String name)
 {
    Nom = name;
}
 
        public void affiche()
    {
      System.out.println("Je suis un point de coordonnées (" + x +","+ y + ").");
    }
        
     public void affiche(String chaine)
     {
      System.out.println("Je suis un point de nom "+chaine);
     }
    public void incrementeX(){
        x++;
    }
    public void changeName(String nouvNom){
        Nom=nouvNom;
    }
    
    @Override
    public String toString()
    {
        return "nom=" + Nom + " abscisse=" + x + " ordonnee=" + y;
    }

  public String getNom()
  {
    return Nom;
  }

    public int getX()
  {
    return x;
  }
    
  public int getY()
  {
    return y;
  }
  
  public void setNom(String name)
  {
    this.Nom = name;
    
  }

    public void setX(int x2)
  {
    this.x = x2;
    
  }
    
  public void setY(int y2)
  {
    this.y = y2;
   
  }
  
}














