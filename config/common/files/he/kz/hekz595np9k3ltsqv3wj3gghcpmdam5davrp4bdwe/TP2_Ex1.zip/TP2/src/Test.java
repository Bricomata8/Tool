/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author karll
 */
import java.util.Scanner;
public class Test {
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
    
    Point p1 = new Point();
    int abssice, ordonne;
    String name;
    System.out.println("Saisir coordonnes x : ");
            abssice = sc.nextInt();
   System.out.println("Saisir coordonnes y : ");
             ordonne = sc.nextInt();
             
    Point p2 = new Point(abssice,ordonne);
    
    System.out.println("Saisir un Nom : ");
            name = sc.next();
            
    Point p3 = new Point(name);
    
    p2.setNom(name);
    
    p1.affiche();
    p1.affiche("Karl");
    p1.changeName("karlito");
    p1.incrementeX();
    p1.toString();
    p1.affiche(p1.toString());
    
    p2.affiche();
    p2.affiche("Paul");
    p2.changeName("paulo");
    p2.incrementeX();
    p2.toString();
      p2.affiche(p2.toString());
    
    p3.affiche();
    p3.affiche("valentin");
    p3.changeName("julien");
    p3.incrementeX();
    p3.toString();
    p3.affiche(p3.toString());
   
    
            
    
             
    
    
    
    }
}










