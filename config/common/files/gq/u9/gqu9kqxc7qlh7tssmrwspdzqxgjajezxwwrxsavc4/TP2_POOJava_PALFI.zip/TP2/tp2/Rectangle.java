/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp2;

/**
 *
 * @author Emma
 */

    public class Rectangle extends Polygone {
    
    // Attributs
    private double perimetre;
    private double surface;
    
    // Constructeurs
    public Rectangle(Segment tab[])
    {
        super(tab);
    }
    // Méthodes
    public double Perimetre()
    {
        double perimeter = 0;
        
        for(int i=0; i<nb_seg; i++)
        {
            perimeter = perimeter + tab[i].getWidth();
        }
        
        return perimeter;
    }
    
     public double Surface()
    {
        double S;
        double p = perimetre/2;
        double a = tab[0].getWidth();
        double b = tab[1].getWidth();
        
       S = a*b;
       
        return S;
    }
}


