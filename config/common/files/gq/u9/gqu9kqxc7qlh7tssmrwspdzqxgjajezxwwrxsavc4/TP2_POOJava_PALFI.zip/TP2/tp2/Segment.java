/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp2;

/**
 *
 * @author Emma
 */
public class Segment {
    
    // Attributs
    private Point p1;
    private Point p2;
    private double width;
    
    // Constructeur
    private Segment()
    {
        
    }
    
    // Constructeur surchargé
    public Segment(Point p1, Point p2)
    {
        this.p1 = p1;
        this.p2 = p2;
    }
    
    // Getters
     public Point getP1()
    {
        return p1;
    }
    
    public Point getP2()
    {
        return p2;
    }
    
    public double getWidth()
    {
        return width;
    }
    
    // Méthodes
    public double calcule()
    {
        double deltaX = p2.getX() - p1.getX();
        double deltaXcarre = +Math.pow(deltaX,2);
        
        double deltaY = p2.getY() - p1.getY();
        double deltaYcarre = +Math.pow(deltaY,2);
        
        width =  +Math.sqrt(deltaXcarre + deltaYcarre) ;
        return width;
    }
    
    public void deplace(int dx, int dy)
    {
        p1.deplace(dx, dy);
        p2.deplace(dx, dy);  
    }
    
    public void affiche()
    {
        System.out.println("SEGMENT");
        System.out.println("longueur: " + width);
        p1.affiche();
        p2.affiche();
    }
    
    public String toString() 
    {
        return  "Premier point " + p1.toString()+
                " Deuxieme point " + p2.toString() +
                " Longueur " + this.width;
    }
    
    public void affiche(String s)
    {
        
    }
}


