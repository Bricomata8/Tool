/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp2;

/**
 *
 * @author Emma
 */

import java.util.Scanner;

public class Test {
    
     public static void main(String[] args){
     
         Scanner sc = new Scanner(System.in);
         
         /// EXERCICE 1
         
         // POINTS
         Point p1 = new Point();
         
         System.out.println("Veuillez entrer les coordonnés du point");
         int x2 = sc.nextInt();
         int y2 = sc.nextInt();
         Point p2 = new Point(x2,y2);
         
         System.out.println("Veuillez saisir un nom de point");
         String name3 = sc.next();
         Point p3 = new Point(name3);
         p2.SetName(name3);
         
         p1.affiche();
         p2.affiche();
         p3.affiche();
         
         // SEGMENTS
         Segment s1 = new Segment(p1, p2);
         s1.calcule();
         s1.affiche();
         Segment s2 = new Segment(p2, p3);
         s2.calcule();
         s2.affiche();
         s1.deplace(p3.getX(), p3.getY());
         s1.affiche();
         
         /// EXERCICE 2
         
         // POINTS
         Point p4 = new Point(1,1);
         p4.SetName("A");
         Point p5 = new Point(3,7);
         p5.SetName("B");
         Point p6 = new Point(4,5);
         p6.SetName("C");
         Point p7 = new Point(7,7);
         p7.SetName("D");
         
         // SEGMENTS
         Segment s4 = new Segment(p4,p5);
         s4.calcule();
         Segment s6 = new Segment(p5,p6);
         s6.calcule();
         Segment s7 = new Segment(p6,p4);
         s7.calcule();
         
         // TABLEAU DE SEGMENTS
         Segment tab[] = new Segment[3];
         tab[0] = s4;
         tab[1] = s6;
         tab[2] = s7;
         
         // POLYGONE
         Polygone po1 = new Polygone(tab);
         
         // TRIANGLE
         Triangle t1 = new Triangle(tab);
         t1.setPerimetre(t1.perimetre());
         t1.setSurface(t1.surface());
         t1.afficher();     
     } 
}
