/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp2;

/**
 *
 * @author Emma
 */
public class Polygone {
    
    // Attributs (protected car héritage)
    protected Segment tab[];
    protected int nb_seg;
    
    // Constructeurs
    public Polygone()
    {
        
    }
    
    // constructeur surchargé
    public Polygone(int nb_seg)
    {
        this.nb_seg = nb_seg;
        this.tab = new Segment[nb_seg];
    }
    
    // Constructeur surchargé
     public Polygone(Segment[] tab)
    {
        this.tab = new Segment[tab.length];
        this.tab = tab;
    }
     
    // Méthodes
    public void deplace(int dx, int dy)
    {
        for(int i=0; i<nb_seg; i++)
        {
            tab[i].getP1().deplace(dx, dy);
            tab[i].getP2().deplace(dx, dy);
        }
    }
    
    public void affiche()
    {
        nb_seg = tab.length; 
        for(int i=0; i<nb_seg; i++)
        {
            tab[i].affiche();
        }
    }
    
}
