/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp2;

/**
 *
 * @author Emma
 */
public class Point {
    
    // Attributs
    private int x;
    private int y;
    private String name;
    
    // Constructeur
    public Point()
    {
        
    }
    
    // Constructeur surchargé
    public Point(int x, int y)
    {
        Point p = new Point();
        this.name = p.name;
        this.x = x;
        this.y = y; 
    }
    
    // Constructeur surchargé
     public Point(String name)
    {
        Point p = new Point();
        this.x = p.x;
        this.y = p.y;
        this.name = name;
    }
     
    // Setters
    public void SetName(String name)
    {
        this.name = name;
    }
    
    public String getName()
    {
        return name;
    }
    
    // Getters
    public int getX()
    {
        return x;
    }
    
    public int getY()
    {
        return y;
    }
    
    // Méthodes
    public void affiche()
    {
        System.out.println( name + "(" + x + ", " + y + ")" );
    }
    
    public void deplace(int dx, int dy)
    {
       x =+ dx;
       y =+ dy;
    }
}
