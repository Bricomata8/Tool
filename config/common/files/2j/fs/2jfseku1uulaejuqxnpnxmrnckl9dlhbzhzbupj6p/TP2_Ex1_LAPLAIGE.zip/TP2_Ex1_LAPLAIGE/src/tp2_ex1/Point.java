/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp2_ex1;

/**
 *
 * @author Paul
 */
public class Point {
    private int x,y;
    private String nom;
    
    public Point()
    {
        x = 0;
        y = 0;
        nom = null;
    }
    
    public Point(int px,int py)
    {
        x = px;
        y = py;        
    }
    
    public Point(String pNom)
    {
        nom = pNom;
    }
    
    @Override
    public String toString()
    {
        return "nom=" + nom + " abscisse=" + x + " ordonnee=" + y;
    }
    public void affiche()
    {
      System.out.println("Je suis un point "+
	"de coordonnées (" + x +","+ y + ").");
    }
    public void affiche(String chaine)
    {
      System.out.println("Je suis un point nommé "+chaine);
    }
    public void incrementeX()
    {
        x++;
    }
    public void changeName(String nouvNom)
    {
        nom=nouvNom;
    }
    
    public int getX()
    {
        return x;
    }
    
    public int getY()
    {
        return y;
    }
    
    public String getNom()
    {
        return nom;
    }
    
    public void setX(int px) 
    {
        this.x = px;
    }
    
    public void setY(int py) 
    {
        this.y = py;
    }
    
    public void setNom(String pNom) 
    {
        this.nom = pNom;
    }
    
}
