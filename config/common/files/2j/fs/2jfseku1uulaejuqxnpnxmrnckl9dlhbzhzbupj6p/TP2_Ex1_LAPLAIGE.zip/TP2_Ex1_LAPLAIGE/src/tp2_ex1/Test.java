/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp2_ex1;
import java.util.Scanner;

/**
 *
 * @author Paul
 */
public class Test {
    public static void main(String[]args)
    {
        Scanner sc = new Scanner(System.in);
        
        Point p1 = new Point();
        
        int abs,ord;
        System.out.println("Saisir abscisse :");
        abs = sc.nextInt();
        System.out.println("Saisir ordonnée :");
        ord = sc.nextInt();
        Point p2 = new Point(abs,ord);
        
        String nom;
        System.out.println("Saisir nom :");
        nom = sc.next();
        Point p3 = new Point(nom);
        
        p2.setNom(nom);
        
        p1.affiche();
        p1.affiche("paul1");
        p1.changeName("paul 1");
        p1.incrementeX();
        p1.affiche(p1.toString());
        
        p2.affiche();
        p2.affiche("paul2");
        p2.changeName("paul 2");
        p2.incrementeX();
        p2.affiche(p2.toString());
        
        p3.affiche();
        p3.affiche("paul3");
        p3.changeName("paul 3");
        p3.incrementeX();
        p3.affiche(p3.toString());
    }
}
