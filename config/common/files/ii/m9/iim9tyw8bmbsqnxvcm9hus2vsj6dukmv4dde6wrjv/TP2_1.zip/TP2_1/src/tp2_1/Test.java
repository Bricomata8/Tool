/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp2_1;
import java.util.Scanner;

/**
 *
 * @author valentin
 */
public class Test {
    
    public static void main (String[]args)
    {
    Scanner sc = new Scanner(System.in);
    Point p1 = new Point();
    int abs,ord;
    System.out.println("saisir abs :");
    abs= sc.nextInt();
    System.out.println("saisir ord :");
    ord= sc.nextInt();
    
    Point p2 =new Point(abs,ord);
    String nom;
    System.out.println("saisir nom :");
    nom= sc.next();
    
    Point p3 = new Point(nom);
    p2.setNom(nom);
    
    p1.affiche();
    p1.affiche("aiden");
    p1.changeName("aidenf");
    p1.incrementeX();
    p1.affiche(p1.toString());
    
    
    p2.affiche();
    p2.affiche("aiden1");
    p2.changeName("aidenf1");
    p2.incrementeX();
    p2.affiche(p1.toString());
    
    
    p3.affiche();
    p3.affiche("aiden2");
    p3.changeName("aidenf2");
    p3.incrementeX();
    p3.affiche(p1.toString());
    
    }
    
    
}
