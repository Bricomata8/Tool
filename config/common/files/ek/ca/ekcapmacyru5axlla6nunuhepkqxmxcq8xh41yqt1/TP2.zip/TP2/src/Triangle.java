
public class Triangle extends Polygone  {
	int perimetre;
	int surface;
	int p=perimetre/2;
	
	public int calcul_peri() {
		perimetre=3*nb_segments;
		return perimetre;
	}

	public int calcul_surface() {
		surface=Math.sqrt(3*p*(p-nb_segments));
		return surface;
	}
}
