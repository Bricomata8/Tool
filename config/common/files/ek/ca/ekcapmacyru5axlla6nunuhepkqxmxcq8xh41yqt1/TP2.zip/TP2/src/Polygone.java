
public class Polygone {
	int nb_segments;
	Segment tab[]=new Segment[nb_segments];
	
	public Polygone() {
		
	}
	
	public Polygone(int nb_segments) {
		this.nb_segments=nb_segments;

	}
	
	public Polygone(Segment tab[]) {
		this.tab=tab;
	}
}
