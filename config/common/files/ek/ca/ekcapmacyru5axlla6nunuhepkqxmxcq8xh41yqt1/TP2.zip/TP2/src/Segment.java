
public class Segment {

	private int longueur_seg;
	Point i;
	Point j;
	
	public Segment(Point i, Point j) {
		this.i=i;
		this.j=j;
	}
	
	public int calclongueur_seg() {
		longueur_seg = j.x-i.x;
		return longueur_seg;
	}
	
	public void setBeginning(Point beginning) {
		this.beginning=beginning;
	}
	
	public void deplacer(int x, int y) {
		
	}
	
	@Override to String() {
		toString();
	}
	
}
