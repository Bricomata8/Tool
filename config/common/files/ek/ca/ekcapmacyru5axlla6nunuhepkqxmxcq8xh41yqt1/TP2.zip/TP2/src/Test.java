
public class Test {

	
	public static void main(String[] args)
	{
		Point p1=new Point(3,5);
		Point p2=new Point(0,2);
		Point p3=new Point("z");
		
		System.out.println(p1);
		System.out.println(p2);
		
		Segment s1 = new Segment(p1, p2);
		Segment s2 = new Segment(p2, p3);
		
		System.out.println(s1);
		System.out.println(s2);
		
		s1.deplacer(2,2);
		s2.deplacer(2,2);
		
		System.out.println("Apres deplacement");
		System.out.println(s1);
		System.out.println(s2);
		
		
		Triangle T;

	}

}
