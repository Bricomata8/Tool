
public class Rectangle extends Polygone {
	int perimetre_r;
	int surface_r;
	
	public Rectangle() {
		
	}
}
