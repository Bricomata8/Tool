
public class Point {
	private String name;
	private int x,y;
	
	public Point(int x, int y)
	{
		this.x=x;
		this.y=y;	
	}
	
	
	public Point(String nom) {
		
	}
	
	public Point(Point p) {
		this.x=p.x;
		this.y=p.y;
	}
	
	public int getY(){
		return y;	
	}
	
	public void setY(int y) {
		this.x=x;
	}
	
	public String toString(){
		return("("+x+","+y+")");
	}
	
	public void deplacer(int dx, int dy) {
		x=x+dx;
		y=y+dy;
	}
}
