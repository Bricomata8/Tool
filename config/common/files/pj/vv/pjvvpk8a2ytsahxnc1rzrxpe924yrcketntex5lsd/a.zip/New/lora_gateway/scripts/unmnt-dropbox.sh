#!/bin/bash

fusermount -u ~/Dropbox
