#!/bin/sh

rm -rf use_3GDongle_internet_on_boot.txt